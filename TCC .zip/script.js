function playGame() {
  window.location.href = "entrada.html";
    // Código para iniciar o jogo
}

function showInstructions() {
    window.location.href = "instrução.html";
}

function exitPage() {
    window.open('', '_self', '');
    window.close();
}